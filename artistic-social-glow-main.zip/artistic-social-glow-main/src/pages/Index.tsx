import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Users, TrendingUp, Target, Zap, Heart, Star, Menu, X } from "lucide-react";
import { useEffect, useState } from "react";

const Index = () => {
  const [cursorPosition, setCursorPosition] = useState({ x: 0, y: 0 });
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setCursorPosition({ x: e.clientX, y: e.clientY });
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.body.style.cursor = 'none';

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.body.style.cursor = 'auto';
    };
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      {/* Custom Cursor */}
      <div 
        className="fixed w-3 h-3 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full pointer-events-none z-50 transition-transform duration-100 ease-out"
        style={{ 
          left: cursorPosition.x - 6, 
          top: cursorPosition.y - 6,
          transform: 'translate3d(0, 0, 0)'
        }}
      />

      {/* Floating Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Floating circles */}
        <div className="absolute top-20 left-10 w-4 h-4 bg-yellow-400/20 rounded-full animate-bounce" style={{ animationDelay: '0s', animationDuration: '3s' }} />
        <div className="absolute top-40 right-20 w-6 h-6 bg-yellow-500/15 rounded-full animate-bounce" style={{ animationDelay: '1s', animationDuration: '4s' }} />
        <div className="absolute bottom-40 left-20 w-3 h-3 bg-yellow-600/25 rounded-full animate-bounce" style={{ animationDelay: '2s', animationDuration: '5s' }} />
        <div className="absolute top-60 left-1/3 w-5 h-5 bg-yellow-400/10 rounded-full animate-bounce" style={{ animationDelay: '0.5s', animationDuration: '3.5s' }} />
        <div className="absolute bottom-60 right-1/4 w-4 h-4 bg-yellow-500/20 rounded-full animate-bounce" style={{ animationDelay: '1.5s', animationDuration: '4.5s' }} />
        
        {/* Floating squares */}
        <div className="absolute top-32 right-10 w-3 h-3 bg-yellow-400/15 rotate-45 animate-pulse" style={{ animationDelay: '0s', animationDuration: '2s' }} />
        <div className="absolute bottom-32 left-1/4 w-4 h-4 bg-yellow-500/10 rotate-45 animate-pulse" style={{ animationDelay: '1s', animationDuration: '3s' }} />
        <div className="absolute top-1/2 right-1/3 w-2 h-2 bg-yellow-600/20 rotate-45 animate-pulse" style={{ animationDelay: '0.5s', animationDuration: '2.5s' }} />
        
        {/* Floating lines */}
        <div className="absolute top-24 left-1/2 w-16 h-0.5 bg-gradient-to-r from-transparent via-yellow-400/30 to-transparent animate-pulse" style={{ animationDelay: '0s', animationDuration: '4s' }} />
        <div className="absolute bottom-24 right-1/2 w-12 h-0.5 bg-gradient-to-r from-transparent via-yellow-500/20 to-transparent animate-pulse" style={{ animationDelay: '2s', animationDuration: '3s' }} />
      </div>

      {/* Header */}
      <header className="border-b border-gray-800 sticky top-0 bg-black/95 backdrop-blur-sm z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
            Artistics
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-gray-300 hover:text-yellow-400 transition-colors">Home</a>
            <a href="#services" className="text-gray-300 hover:text-yellow-400 transition-colors">Services</a>
            <a href="#about" className="text-gray-300 hover:text-yellow-400 transition-colors">About</a>
            <a href="#contact" className="text-gray-300 hover:text-yellow-400 transition-colors">Contact</a>
          </nav>

          {/* Mobile Hamburger Menu */}
          <button 
            className="md:hidden text-white hover:text-yellow-400 transition-colors"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-black/95 backdrop-blur-sm border-t border-gray-800">
            <nav className="container mx-auto px-4 py-4 flex flex-col space-y-4">
              <a href="#home" className="text-gray-300 hover:text-yellow-400 transition-colors" onClick={toggleMenu}>Home</a>
              <a href="#services" className="text-gray-300 hover:text-yellow-400 transition-colors" onClick={toggleMenu}>Services</a>
              <a href="#about" className="text-gray-300 hover:text-yellow-400 transition-colors" onClick={toggleMenu}>About</a>
              <a href="#contact" className="text-gray-300 hover:text-yellow-400 transition-colors" onClick={toggleMenu}>Contact</a>
            </nav>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section id="home" className="relative overflow-hidden bg-black">
        <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/5 to-yellow-600/5"></div>
        <div className="container mx-auto px-4 py-20 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <Badge variant="secondary" className="bg-gray-900 text-yellow-400 hover:bg-gray-800 border border-yellow-400/20">
                🚀 Social Media Marketing Experts
              </Badge>
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight text-white">
                Grow Your Brand with
                <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                  {" "}Strategic Social Media
                </span>
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed">
                Transform your social media presence with our data-driven marketing strategies. 
                We help businesses connect with their audience and drive meaningful results.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-yellow-400/30 text-yellow-400 hover:bg-yellow-400/10 hover:border-yellow-400"
                  onClick={() => window.open('https://wa.me/1234567890', '_blank')}
                >
                  <svg className="mr-2 h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.63z"/>
                  </svg>
                  Chat on WhatsApp
                </Button>
              </div>
              
              {/* ... keep existing code (stats section) */}
              <div className="flex items-center space-x-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400">500+</div>
                  <div className="text-sm text-gray-400">Happy Clients</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400">2M+</div>
                  <div className="text-sm text-gray-400">Followers Gained</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400">98%</div>
                  <div className="text-sm text-gray-400">Success Rate</div>
                </div>
              </div>
            </div>
            
            {/* ... keep existing code (right side grid with cards) */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 to-yellow-600/20 rounded-3xl transform rotate-3"></div>
              <div className="relative bg-gray-900 rounded-3xl shadow-2xl p-8 transform -rotate-1 hover:rotate-0 transition-transform duration-300 border border-gray-800">
                <div className="grid grid-cols-2 gap-6">
                  <Card className="border-0 shadow-lg bg-gray-800 border border-gray-700">
                    <CardContent className="p-6 text-center">
                      <TrendingUp className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
                      <h3 className="font-semibold text-white mb-2">Growth Analytics</h3>
                      <p className="text-sm text-gray-400">Real-time insights</p>
                    </CardContent>
                  </Card>
                  <Card className="border-0 shadow-lg bg-gray-800 border border-gray-700">
                    <CardContent className="p-6 text-center">
                      <Heart className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
                      <h3 className="font-semibold text-white mb-2">Engagement</h3>
                      <p className="text-sm text-gray-400">Authentic connections</p>
                    </CardContent>
                  </Card>
                  <Card className="border-0 shadow-lg bg-gray-800 border border-gray-700">
                    <CardContent className="p-6 text-center">
                      <Target className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
                      <h3 className="font-semibold text-white mb-2">Targeting</h3>
                      <p className="text-sm text-gray-400">Precision marketing</p>
                    </CardContent>
                  </Card>
                  <Card className="border-0 shadow-lg bg-gray-800 border border-gray-700">
                    <CardContent className="p-6 text-center">
                      <Zap className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
                      <h3 className="font-semibold text-white mb-2">Automation</h3>
                      <p className="text-sm text-gray-400">Smart workflows</p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="bg-gray-900 text-yellow-400 hover:bg-gray-800 border border-yellow-400/20 mb-4">
              Our Services
            </Badge>
            <h2 className="text-4xl font-bold mb-6 text-white">
              Complete Social Media Solutions
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              From strategy development to content creation and community management, 
              we provide end-to-end social media marketing services.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Content Strategy",
                description: "Develop compelling content strategies that resonate with your target audience and drive engagement.",
                icon: "📝",
                color: "from-yellow-400 to-yellow-600"
              },
              {
                title: "Social Media Management",
                description: "Complete management of your social media presence across all major platforms.",
                icon: "📱",
                color: "from-yellow-500 to-yellow-700"
              },
              {
                title: "Paid Advertising",
                description: "Strategic paid campaigns that maximize ROI and drive qualified leads to your business.",
                icon: "🎯",
                color: "from-yellow-400 to-yellow-500"
              },
              {
                title: "Analytics & Reporting",
                description: "Comprehensive analytics and detailed reporting to track performance and optimize strategies.",
                icon: "📊",
                color: "from-yellow-500 to-yellow-600"
              },
              {
                title: "Community Building",
                description: "Build and nurture engaged communities around your brand across social platforms.",
                icon: "👥",
                color: "from-yellow-400 to-yellow-700"
              },
              {
                title: "Influencer Marketing",
                description: "Connect with relevant influencers to amplify your brand message and reach new audiences.",
                icon: "⭐",
                color: "from-yellow-500 to-yellow-400"
              }
            ].map((service, index) => (
              <Card key={index} className="group hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-0 shadow-lg bg-gray-900 border border-gray-800">
                <CardContent className="p-8">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${service.color} flex items-center justify-center text-2xl mb-6`}>
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-4 group-hover:text-yellow-400 transition-colors text-white">
                    {service.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-950">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <Badge variant="secondary" className="bg-gray-900 text-yellow-400 hover:bg-gray-800 border border-yellow-400/20">
                About Artistics
              </Badge>
              <h2 className="text-4xl font-bold text-white">
                We're Your Social Media
                <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                  {" "}Growth Partners
                </span>
              </h2>
              <p className="text-lg text-gray-300 leading-relaxed">
                With over 5 years of experience in social media marketing, we've helped hundreds of businesses 
                transform their online presence and achieve remarkable growth. Our team of experts stays ahead 
                of the latest trends and algorithm changes to ensure your brand always performs at its best.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center p-6 bg-gray-900 rounded-2xl shadow-lg border border-gray-800">
                  <div className="text-3xl font-bold text-yellow-400 mb-2">5+</div>
                  <div className="text-gray-400">Years Experience</div>
                </div>
                <div className="text-center p-6 bg-gray-900 rounded-2xl shadow-lg border border-gray-800">
                  <div className="text-3xl font-bold text-yellow-400 mb-2">50+</div>
                  <div className="text-gray-400">Team Members</div>
                </div>
              </div>
              <Button size="lg" className="bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black font-semibold">
                Learn More About Us
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 to-yellow-600/20 rounded-3xl transform -rotate-3"></div>
              <div className="relative bg-gray-900 rounded-3xl shadow-2xl p-8 border border-gray-800">
                <div className="space-y-6">
                  {[
                    { label: "Client Satisfaction", value: 98 },
                    { label: "Project Success Rate", value: 95 },
                    { label: "Average ROI Increase", value: 300 }
                  ].map((stat, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between text-sm font-medium text-white">
                        <span>{stat.label}</span>
                        <span>{stat.value}%</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-yellow-400 to-yellow-600 h-2 rounded-full transition-all duration-1000"
                          style={{ width: `${stat.value}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-yellow-400 to-yellow-600">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-black">
              Ready to Transform Your Social Media Presence?
            </h2>
            <p className="text-xl text-black/80 leading-relaxed">
              Join hundreds of successful businesses who trust us with their social media marketing. 
              Let's create something amazing together.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" className="bg-black text-yellow-400 hover:bg-gray-900 border-0 font-semibold">
                Get Free Consultation
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="border-black text-black hover:bg-black hover:text-yellow-400 border-2">
                View Our Portfolio
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-black text-white py-16 border-t border-gray-800">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                Artistics
              </div>
              <p className="text-gray-400">
                Your trusted partner for social media marketing success.
              </p>
              <div className="flex space-x-4">
                {["Facebook", "Twitter", "Instagram", "LinkedIn"].map((social) => (
                  <div key={social} className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-yellow-400 hover:text-black transition-colors cursor-pointer border border-gray-700">
                    <span className="text-sm font-semibold">{social[0]}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-white">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-yellow-400 transition-colors">Content Strategy</a></li>
                <li><a href="#" className="hover:text-yellow-400 transition-colors">Social Management</a></li>
                <li><a href="#" className="hover:text-yellow-400 transition-colors">Paid Advertising</a></li>
                <li><a href="#" className="hover:text-yellow-400 transition-colors">Analytics</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-white">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-yellow-400 transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-yellow-400 transition-colors">Our Team</a></li>
                <li><a href="#" className="hover:text-yellow-400 transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-yellow-400 transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-white">Contact Info</h3>
              <div className="space-y-2 text-gray-400">
                <p>📧 hello@artistics.com</p>
                <p>📞 (555) 123-4567</p>
                <p>📍 123 Marketing St, Digital City</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Artistics. All rights reserved. Built with ❤️ for social media success.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
